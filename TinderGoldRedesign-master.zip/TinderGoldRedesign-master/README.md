![tindergoldappdesign](https://user-images.githubusercontent.com/55942632/73542795-85756f00-445b-11ea-8aa9-913ec2075f53.png)

<p>
  <a href="https://twitter.com/Theindianappguy">
    <img src="https://img.shields.io/github/stars/theindianappguy/TinderGoldRedesign?style=for-the-badge" alt="Total downloads on GitHub." /></a>
<a href="https://www.linkedin.com/in/lamsanskar/">
    <img src="https://img.shields.io/badge/Support-Recommed%2FEndorse%20me%20on%20Linkedin-yellow?style=for-the-badge&logo=linkedin" alt="Recommend me on LinkedIn" /></a>

<a href="https://tindergoldredesign.codemagic.app">
    <img src="https://img.shields.io/badge/Flutter%20Web-Live%20Demo-green?style=for-the-badge&logo=flutter" alt="Try Live Demo" /></a>
</p>

Tinder Gold redesign concept for the popular dating app made with Flutter, Hosted on Codemagic. Don't forget to star ⭐ the repo it motivates me to share more open source

Design Credits
[DigitX](https://www.behance.net/gallery/80061363/Social-media-DIGITX)
### Created & Maintained By

[Sanskar Tiwari](https://github.com/theindianappguy) ([@theindianappguy](https://twitter.com/Theindianappguy)) ([YouTube](https://www.youtube.com/c/SanskarTiwari))

> 
>
> - [PayPal](https://paypal.me/iamsanskartiwari)

### License

    Copyright 2020 Sanskar Tiwari

    Licensed under the Apache License, Version 2.0 (the "License");
    you may not use this file except in compliance with the License.
    You may obtain a copy of the License at

       http://www.apache.org/licenses/LICENSE-2.0

    Unless required by applicable law or agreed to in writing, software
    distributed under the License is distributed on an "AS IS" BASIS,
    WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
    See the License for the specific language governing permissions and
    limitations under the License.



