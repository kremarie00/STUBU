// import 'package:flutter/material.dart';

// import 'package:lovely/ui/widgets/signInThroughPhone.dart';

// class SignUp extends StatelessWidget {
//   @override
//   Widget build(BuildContext context) {
//     return SignUpForm();
//   }
// }
