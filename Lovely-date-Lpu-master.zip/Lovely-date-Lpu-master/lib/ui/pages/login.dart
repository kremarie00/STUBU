import 'package:flutter/material.dart';
import 'package:lovely/ui/widgets/loginForm.dart';

class Login extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return LoginForm();
  }
}
