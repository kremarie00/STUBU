class User {
  String uid;
  String name;
  String gender;
  String interestedIn;
  String photo;
  String age;
  String about;

  User(
      {required this.uid,
      required this.name,
      required this.gender,
      required this.interestedIn,
      required this.photo,
      required this.age,
      required this.about});
}
