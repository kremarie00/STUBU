# Lovely
 
Lovely  is an app that has dating and chat features altered for university campuses . The app only allows users who have a registered user id with the university’s user management system also known as LPU - UMS.

## Installation

Use the command to install Lovely.

```bash
gh repo clone prakasharyaman/Lovely-date-Lpu
```


![featuregraphic (1)](https://user-images.githubusercontent.com/63445447/142842171-164b2068-b7f3-469f-a537-90bb15c8b366.png)

## Contributing
Pull requests are welcome. For major changes, please open an issue first to discuss what you would like to change.

Please make sure to update tests as appropriate.

## License
[MIT](https://choosealicense.com/licenses/mit/)
